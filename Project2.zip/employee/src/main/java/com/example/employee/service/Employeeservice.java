package com.example.employee.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.example.employee.entity.Employee;

@Service
public class Employeeservice {

    Map<Integer, Employee> details = new HashMap<>();

    public Employee saveData(Employee emp) {
        details.put(emp.getEmpid(), emp);
        return emp;
    }

    public List<Employee> getEmployees() {
        return new ArrayList<>(details.values());
    }

    public Employee getById(int empid) {
        return details.get(empid);
    }

    public Employee delete(int empid) {
        return details.remove(empid);
    }
}
