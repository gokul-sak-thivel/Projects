package com.example.employee.entity;

public class Employee {

    private int empid;
    private String empname;
    private float empsalary;
    private int empage;

    public int getEmpid() {
        return empid;
    }
    public void setEmpid(int empid) {
        this.empid = empid;
    }

    public String getEmpname() {
        return empname;
    }
    public void setEmpname(String empname) {
        this.empname = empname;
    }

    public float getEmpsalary() {
        return empsalary;
    }
    public void setEmpsalary(float empsalary) {
        this.empsalary = empsalary;
    }

    public int getEmpage() {
        return empage;
    }
    public void setEmpage(int empage) {
        this.empage = empage;
    }
}
